from student import generate_weekly_report

if __name__ == "__main__":
    generate_weekly_report()
    print("Weekly report update successfully.")
