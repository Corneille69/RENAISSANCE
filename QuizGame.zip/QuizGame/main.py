import os
import json
from tkinter import *
from quiz_manager import charger_questions
from score_management import sauvegarder_score

# Fonction pour charger les questions d'un niveau donné
def charger_questions_par_niveau(niveau):
    chemin = os.path.join('Data', 'questions', f'{niveau}.json')
    with open(chemin, 'r', encoding='utf-8') as file:
        return json.load(file)

# Fonction pour afficher une question et ses options
def afficher_question(index, questions, current_question_index, score):
    if current_question_index[0] < len(questions):
        question_label.config(text=questions[current_question_index[0]]['question'])
        for i, option in enumerate(questions[current_question_index[0]]['options']):
            boutons_options[i].config(text=option, command=lambda selected_option=option, index=current_question_index[0]: verifier_reponse(selected_option, index, questions, score, current_question_index))
    else:
        question_label.config(text=f"Quiz terminé! Votre score: {score[0]}/{len(questions)}")
        for bouton in boutons_options:
            bouton.place_forget()
        recommencer_button.place(x=150, y=250)  # Afficher le bouton recommencer

# Fonction pour vérifier la réponse et mettre à jour le score
def verifier_reponse(selected_option, index, questions, score, current_question_index):
    if selected_option == questions[index]['answer']:
        score[0] += 1
        result_label.config(text="Correct!", fg="green")
    else:
        result_label.config(text="Incorrect!", fg="red")
    fenetre.after(1000, lambda: passer_a_question_suivante(questions, current_question_index, score))

# Fonction pour passer à la question suivante
def passer_a_question_suivante(questions, current_question_index, score):
    current_question_index[0] += 1
    afficher_question(current_question_index[0], questions, current_question_index, score)

# Fonction pour recommencer le quiz
def recommencer():
    global current_question_index
    global score
    current_question_index = [0]  # Réinitialiser l'indice de la question
    score = [0]  # Réinitialiser le score
    for widget in second_interface.winfo_children():
        widget.place_forget()
    second_interface.place_forget()
    start_quiz(niveau_courant)  # Relancer le quiz avec le même niveau

# Fonction pour afficher le menu principal
def show_main_menu():
    label.place(x=130, y=10)
    label1.place(x=100, y=80)
    btn1.place(x=145, y=120)
    btn2.place(x=140, y=170)
    btn3.place(x=137, y=220)

# Interface pour le niveau facile
def easy_interface():
    start_quiz("easy")

# Interface pour le niveau moyen
def medium_interface():
    start_quiz("medium")

# Interface pour le niveau difficile
def difficult_interface():
    start_quiz("difficult")

# Fonction pour démarrer un quiz en fonction du niveau
def start_quiz(niveau):
    global niveau_courant
    niveau_courant = niveau
    questions = charger_questions_par_niveau(niveau)  # Charger les questions depuis le fichier JSON
    current_question_index = [0]  # Utilisé pour suivre l'indice de la question actuelle
    score = [0]  # Utilisé pour suivre le score

    # Masquer les widgets de la fenêtre principale et afficher la fenêtre du quiz
    for widget in fenetre.winfo_children():
        widget.place_forget()
    second_interface.place(relx=0.5, rely=0.5, anchor="center")

    # Widgets pour afficher la question et les options
    global question_label
    question_label = Label(second_interface, text="", font=("Arial", 14, "bold"), bg='#87CEEB')
    question_label.place(x=20, y=50)

    global result_label
    result_label = Label(second_interface, text="", font=("Arial", 12, "bold"), bg='#87CEEB')
    result_label.place(x=20, y=250)

    global boutons_options
    boutons_options = []
    y_position = 150
    for _ in range(4):  # Créer 4 boutons pour les options
        bouton = Button(second_interface, text="", bg='#87CEEB', font=("Arial", 12))
        bouton.place(x=100, y=y_position)
        boutons_options.append(bouton)
        y_position += 50

    global recommencer_button
    recommencer_button = Button(second_interface, text="Recommencer", bg="blue", font=("Arial", 14, "bold"), fg="white", command=recommencer)
    recommencer_button.place(x=150, y=250)
    recommencer_button.place_forget()  # Masquer le bouton au début
    # Afficher la première question
    afficher_question(current_question_index[0], questions, current_question_index, score)

# Configuration de la fenêtre principale
fenetre = Tk()
fenetre.geometry('400x600')
fenetre.title('Quiz Game')
fenetre['bg'] = '#87CEEB'
fenetre.resizable(height=False, width=False)

# Interface pour le niveau facile
second_interface = Frame(fenetre, bg='#87CEEB', width=400, height=400)


# Boutons de la fenêtre principale
label = Label(fenetre, text='Bienvenue', font=("Arial", 16, "italic bold"), fg='black', bg='#87CEEB')
label.place(x=130, y=10)
label1 = Label(fenetre, text='Entrez une option', font=("Arial", 16, "italic bold"), fg='white', bg='#87CEEB')
label1.place(x=100, y=80)


# Boutons pour choisir le niveau
btn1 = Button(fenetre, text='Facile', bg="#87CEEB", font=('arial', 14, 'italic bold'), fg='white', command=easy_interface)
btn1.place(x=145, y=120)
btn2 = Button(fenetre, text='Moyen', bg="#87CEEB", font=('arial', 14, 'italic bold'), fg='white', command=medium_interface)
btn2.place(x=140, y=170)
btn3 = Button(fenetre, text='Difficile', bg="#87CEEB", font=('arial', 14, 'italic bold'), fg='white', command=difficult_interface)
btn3.place(x=137, y=220)

# Bouton pour quitter l'application
btn_exit = Button(fenetre, text='Quitter', bg="YELLOW", font=('arial', 14, 'italic bold'), fg='black', command=fenetre.quit)
btn_exit.place(x=150, y=270)

# Lancer la boucle principale de l'application
fenetre.mainloop()
