
import json
import os

def charger_questions(niveau):
    base_dir = os.path.dirname(__file__)
    chemin = os.path.join(base_dir, 'Data', 'questions', f'{niveau}.json')
    with open(chemin, 'r', encoding='utf-8') as fichier:
        questions = json.load(fichier)
    return questions
