
import os

def sauvegarder_score(niveau, pseudo, score, total):
    ligne = f"{pseudo} a obtenu {score}/{total} au niveau {niveau}\n"
    base_dir = os.path.dirname(__file__)
    chemin = os.path.join(base_dir, 'Data', 'scores.txt')
    with open(chemin, 'a', encoding='utf-8') as fichier:
        fichier.write(ligne)
