// Script pour la page d'authentification
document.addEventListener('DOMContentLoaded', function() {
  // Éléments du DOM
  const loginTab = document.getElementById('login-tab');
  const registerTab = document.getElementById('register-tab');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const userDashboard = document.getElementById('user-dashboard');
  const authTitle = document.getElementById('auth-title');
  const authSubtitle = document.getElementById('auth-subtitle');
  const messageEl = document.getElementById('message');
  
  // Formulaires
  const loginFormEl = document.getElementById('login');
  const registerFormEl = document.getElementById('register');
  
  // Dashboard
  const userWelcome = document.getElementById('user-welcome');
  const logoutBtn = document.getElementById('logout-btn');
  const loansList = document.getElementById('loans-list');

  // Initialisation
  init();

  function init() {
    setupEventListeners();
    updateUI();
  }

  function setupEventListeners() {
    // Onglets
    loginTab?.addEventListener('click', () => switchTab('login'));
    registerTab?.addEventListener('click', () => switchTab('register'));
    
    // Formulaires
    loginFormEl?.addEventListener('submit', handleLogin);
    registerFormEl?.addEventListener('submit', handleRegister);
    
    // Déconnexion
    logoutBtn?.addEventListener('click', handleLogout);
  }

  function switchTab(tab) {
    if (tab === 'login') {
      loginTab.classList.add('active');
      registerTab.classList.remove('active');
      loginForm.style.display = 'block';
      registerForm.style.display = 'none';
      authTitle.textContent = 'Connexion';
      authSubtitle.textContent = 'Accédez à vos prêts sauvegardés';
    } else {
      registerTab.classList.add('active');
      loginTab.classList.remove('active');
      registerForm.style.display = 'block';
      loginForm.style.display = 'none';
      authTitle.textContent = 'Inscription';
      authSubtitle.textContent = 'Créez votre compte ZenLoan';
    }
    clearMessage();
  }

  function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    
    // Validation basique
    if (!email || !password) {
      showMessage('Veuillez remplir tous les champs', 'error');
      return;
    }

    if (!window.authManager.validateEmail(email)) {
      showMessage('Adresse e-mail invalide', 'error');
      return;
    }

    // Tentative de connexion
    const result = window.authManager.login(email, password);
    
    if (result.success) {
      showMessage(result.message, 'success');
      setTimeout(() => {
        updateUI();
        clearForms();
      }, 1500);
    } else {
      showMessage(result.message, 'error');
    }
  }

  function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm').value;
    
    // Validation
    if (!name || !email || !password || !confirmPassword) {
      showMessage('Veuillez remplir tous les champs', 'error');
      return;
    }

    if (!window.authManager.validateEmail(email)) {
      showMessage('Adresse e-mail invalide', 'error');
      return;
    }

    if (!window.authManager.validatePassword(password)) {
      showMessage('Le mot de passe doit contenir au moins 6 caractères', 'error');
      return;
    }

    if (password !== confirmPassword) {
      showMessage('Les mots de passe ne correspondent pas', 'error');
      return;
    }

    // Tentative d'inscription
    const result = window.authManager.register(name, email, password);
    
    if (result.success) {
      showMessage(result.message, 'success');
      setTimeout(() => {
        updateUI();
        clearForms();
      }, 1500);
    } else {
      showMessage(result.message, 'error');
    }
  }

  function handleLogout() {
    window.authManager.logout();
    updateUI();
    showMessage('Déconnexion réussie', 'success');
  }

  function updateUI() {
    const isAuth = window.authManager?.isAuthenticated();
    const currentUser = window.authManager?.getCurrentUser();
    
    if (isAuth && currentUser) {
      // Afficher le dashboard
      loginForm.style.display = 'none';
      registerForm.style.display = 'none';
      userDashboard.style.display = 'block';
      document.querySelector('.auth-tabs').style.display = 'none';
      
      // Mettre à jour les informations utilisateur
      userWelcome.textContent = `Bienvenue, ${currentUser.name}`;
      authTitle.textContent = 'Mon compte';
      authSubtitle.textContent = 'Gérez vos prêts et paramètres';
      
      // Charger les prêts
      loadUserLoans();
    } else {
      // Afficher les formulaires
      userDashboard.style.display = 'none';
      document.querySelector('.auth-tabs').style.display = 'flex';
      
      // Afficher l'onglet de connexion par défaut
      switchTab('login');
    }
  }

  function loadUserLoans() {
    const currentUser = window.authManager?.getCurrentUser();
    if (!currentUser || !currentUser.loans) {
      showEmptyLoans();
      return;
    }

    const loans = currentUser.loans;
    
    if (loans.length === 0) {
      showEmptyLoans();
      return;
    }

    // Afficher les prêts
    loansList.innerHTML = '';
    loans.forEach(loan => {
      const loanElement = createLoanElement(loan);
      loansList.appendChild(loanElement);
    });
  }

  function createLoanElement(loan) {
    const loanDiv = document.createElement('div');
    loanDiv.className = 'loan-item';
    
    const createdDate = new Date(loan.createdAt).toLocaleDateString();
    
    loanDiv.innerHTML = `
      <div class="loan-header">
        <h4 class="loan-name">${loan.name}</h4>
        <span class="loan-date">${createdDate}</span>
      </div>
      <div class="loan-details">
        <div class="loan-detail">
          <span class="detail-label">Montant</span>
          <span class="detail-value">${LoanCalculator.formatCurrency(loan.amount, loan.currency)}</span>
        </div>
        <div class="loan-detail">
          <span class="detail-label">Taux</span>
          <span class="detail-value">${loan.rate}%</span>
        </div>
        <div class="loan-detail">
          <span class="detail-label">Durée</span>
          <span class="detail-value">${loan.duration} ${loan.durationType === 'years' ? 'ans' : 'mois'}</span>
        </div>
        <div class="loan-detail">
          <span class="detail-label">Mensualité</span>
          <span class="detail-value">${LoanCalculator.formatCurrency(loan.monthlyPayment, loan.currency)}</span>
        </div>
      </div>
      <div class="loan-actions">
        <button type="button" class="btn btn-small btn-outline" onclick="viewLoan('${loan.id}')">
          Voir détails
        </button>
        <button type="button" class="btn btn-small btn-danger" onclick="deleteLoan('${loan.id}')">
          Supprimer
        </button>
      </div>
    `;
    
    return loanDiv;
  }

  function showEmptyLoans() {
    loansList.innerHTML = `
      <div class="empty-state">
        <h3>Aucun prêt sauvegardé</h3>
        <p>Utilisez le calculateur pour créer et sauvegarder vos premiers calculs de prêt.</p>
        <a href="calculator.html" class="btn btn-primary">
          Commencer un calcul
        </a>
      </div>
    `;
  }

  function showMessage(message, type = 'info') {
    messageEl.textContent = message;
    messageEl.className = `message ${type}`;
    messageEl.style.display = 'block';
    
    // Masquer automatiquement après 5 secondes
    setTimeout(() => {
      messageEl.style.display = 'none';
    }, 5000);
  }

  function clearMessage() {
    messageEl.style.display = 'none';
  }

  function clearForms() {
    loginFormEl?.reset();
    registerFormEl?.reset();
  }

  // Fonctions globales pour les actions sur les prêts
  window.viewLoan = function(loanId) {
    // Rediriger vers le calculateur avec les données du prêt
    const currentUser = window.authManager?.getCurrentUser();
    if (!currentUser) return;
    
    const loan = currentUser.loans.find(l => l.id === loanId);
    if (!loan) return;
    
    // Stocker temporairement les données du prêt
    sessionStorage.setItem('zenloan_temp_loan', JSON.stringify(loan));
    
    // Rediriger vers le calculateur
    window.location.href = 'calculator.html';
  };

  window.deleteLoan = function(loanId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce prêt ?')) {
      return;
    }
    
    const result = window.authManager.deleteLoan(loanId);
    
    if (result.success) {
      showMessage(result.message, 'success');
      loadUserLoans(); // Recharger la liste
    } else {
      showMessage(result.message, 'error');
    }
  };

  // Gestion de la touche Entrée pour la navigation entre champs
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      const activeElement = document.activeElement;
      
      // Si on est dans un champ de formulaire, passer au suivant
      if (activeElement.tagName === 'INPUT' && activeElement.type !== 'submit') {
        const form = activeElement.closest('form');
        if (form) {
          const inputs = Array.from(form.querySelectorAll('input:not([type="submit"])'));
          const currentIndex = inputs.indexOf(activeElement);
          
          if (currentIndex < inputs.length - 1) {
            e.preventDefault();
            inputs[currentIndex + 1].focus();
          }
        }
      }
    }
  });
});