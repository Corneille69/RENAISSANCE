// Script pour la page calculateur
document.addEventListener('DOMContentLoaded', function() {
  // Éléments du DOM
  const loanForm = document.getElementById('loan-form');
  const loanSummary = document.getElementById('loan-summary');
  const amortizationSection = document.getElementById('amortization-section');
  const amortizationBody = document.getElementById('amortization-body');
  const authenticatedActions = document.getElementById('authenticated-actions');
  
  // Éléments du résumé
  const monthlyPaymentEl = document.getElementById('monthly-payment');
  const totalCostEl = document.getElementById('total-cost');
  const totalInterestEl = document.getElementById('total-interest');
  
  // Graphique
  let paymentChart = null;
  
  // Modal de sauvegarde
  const saveModal = document.getElementById('save-modal');
  const saveLoanBtn = document.getElementById('save-loan');
  const modalClose = document.getElementById('modal-close');
  const cancelSave = document.getElementById('cancel-save');
  const confirmSave = document.getElementById('confirm-save');
  const loanNameInput = document.getElementById('loan-name');
  
  // Variables pour les données actuelles
  let currentLoanData = null;
  let currentAmortizationSchedule = null;

  // Initialisation
  init();

  function init() {
    // Mettre à jour l'UI selon l'état d'authentification
    updateAuthUI();
    
    // Calculer avec les valeurs par défaut
    calculateLoan();
    
    // Écouteurs d'événements
    setupEventListeners();
  }

  function setupEventListeners() {
    // Soumission du formulaire
    loanForm.addEventListener('submit', function(e) {
      e.preventDefault();
      calculateLoan();
    });

    // Calcul en temps réel lors de la saisie
    const inputs = loanForm.querySelectorAll('input, select');
    inputs.forEach(input => {
      input.addEventListener('input', debounce(calculateLoan, 300));
    });

    // Boutons d'action
    saveLoanBtn?.addEventListener('click', openSaveModal);
    document.getElementById('export-data')?.addEventListener('click', exportData);
    document.getElementById('print-table')?.addEventListener('click', printTable);

    // Modal
    modalClose?.addEventListener('click', closeSaveModal);
    cancelSave?.addEventListener('click', closeSaveModal);
    confirmSave?.addEventListener('click', saveLoan);
    
    // Fermer modal en cliquant à l'extérieur
    saveModal?.addEventListener('click', function(e) {
      if (e.target === saveModal) {
        closeSaveModal();
      }
    });

    // Échap pour fermer la modal
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && saveModal?.style.display !== 'none') {
        closeSaveModal();
      }
    });
  }

  function updateAuthUI() {
    if (window.authManager?.isAuthenticated()) {
      authenticatedActions.style.display = 'block';
    } else {
      authenticatedActions.style.display = 'none';
    }
  }

  function calculateLoan() {
    try {
      // Récupérer les valeurs du formulaire
      const amount = parseFloat(document.getElementById('amount').value);
      const currency = document.getElementById('currency').value;
      const rate = parseFloat(document.getElementById('rate').value);
      const durationType = document.getElementById('duration-type').value;
      const duration = parseInt(document.getElementById('duration').value);

      // Validation
      if (!amount || !rate || !duration || amount <= 0 || rate < 0 || duration <= 0) {
        return;
      }

      // Calculer les détails du prêt
      currentLoanData = LoanCalculator.calculateLoanDetails(amount, rate, duration, durationType);
      currentLoanData.currency = currency;
      currentLoanData.durationType = durationType;
      currentLoanData.originalDuration = duration;

      // Générer le tableau d'amortissement
      currentAmortizationSchedule = LoanCalculator.generateAmortizationSchedule(
        currentLoanData.principal,
        currentLoanData.annualRate,
        currentLoanData.durationMonths
      );

      // Mettre à jour l'affichage
      updateLoanSummary();
      updateChart();
      updateAmortizationTable();
      
      // Afficher les résultats
      loanSummary.style.display = 'block';
      amortizationSection.style.display = 'block';

    } catch (error) {
      console.error('Erreur lors du calcul:', error);
      showMessage('Erreur lors du calcul du prêt', 'error');
    }
  }

  function updateLoanSummary() {
    if (!currentLoanData) return;

    const currency = currentLoanData.currency;
    
    monthlyPaymentEl.textContent = LoanCalculator.formatCurrency(currentLoanData.monthlyPayment, currency);
    totalCostEl.textContent = LoanCalculator.formatCurrency(currentLoanData.totalCost, currency);
    totalInterestEl.textContent = LoanCalculator.formatCurrency(currentLoanData.totalInterest, currency);
  }

  function updateChart() {
    if (!currentAmortizationSchedule) return;

    const ctx = document.getElementById('payment-chart').getContext('2d');
    
    // Détruire le graphique existant
    if (paymentChart) {
      paymentChart.destroy();
    }

    // Préparer les données
    const labels = currentAmortizationSchedule.map(item => `Mois ${item.month}`);
    const principalData = currentAmortizationSchedule.map(item => item.principal);
    const interestData = currentAmortizationSchedule.map(item => item.interest);
    const balanceData = currentAmortizationSchedule.map(item => item.balance);

    // Créer le graphique
    paymentChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Capital remboursé',
            data: principalData,
            borderColor: '#6366f1',
            backgroundColor: 'rgba(99, 102, 241, 0.1)',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Intérêts',
            data: interestData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: true,
            tension: 0.4
          },
          {
            label: 'Solde restant',
            data: balanceData,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            fill: false,
            tension: 0.4,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          intersect: false,
          mode: 'index'
        },
        plugins: {
          title: {
            display: true,
            text: 'Évolution des remboursements'
          },
          legend: {
            position: 'top'
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const value = LoanCalculator.formatCurrency(context.parsed.y, currentLoanData.currency);
                return `${context.dataset.label}: ${value}`;
              }
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: 'Période'
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Montant mensuel'
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'Solde restant'
            },
            grid: {
              drawOnChartArea: false,
            },
          }
        }
      }
    });
  }

  function updateAmortizationTable() {
    if (!currentAmortizationSchedule) return;

    const currency = currentLoanData.currency;
    
    amortizationBody.innerHTML = '';
    
    currentAmortizationSchedule.forEach(item => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${item.month}</td>
        <td>${LoanCalculator.formatCurrency(item.payment, currency)}</td>
        <td>${LoanCalculator.formatCurrency(item.principal, currency)}</td>
        <td>${LoanCalculator.formatCurrency(item.interest, currency)}</td>
        <td>${LoanCalculator.formatCurrency(item.balance, currency)}</td>
      `;
      amortizationBody.appendChild(row);
    });
  }

  function openSaveModal() {
    if (!window.authManager?.isAuthenticated()) {
      showMessage('Vous devez être connecté pour sauvegarder un prêt', 'error');
      return;
    }
    
    loanNameInput.value = '';
    saveModal.style.display = 'flex';
    loanNameInput.focus();
  }

  function closeSaveModal() {
    saveModal.style.display = 'none';
  }

  function saveLoan() {
    const loanName = loanNameInput.value.trim();
    
    if (!loanName) {
      showMessage('Veuillez saisir un nom pour le prêt', 'error');
      return;
    }

    if (!currentLoanData) {
      showMessage('Aucun calcul à sauvegarder', 'error');
      return;
    }

    const loanToSave = {
      name: loanName,
      amount: currentLoanData.principal,
      currency: currentLoanData.currency,
      rate: currentLoanData.annualRate,
      duration: currentLoanData.originalDuration,
      durationType: currentLoanData.durationType,
      monthlyPayment: currentLoanData.monthlyPayment,
      totalCost: currentLoanData.totalCost,
      totalInterest: currentLoanData.totalInterest,
      amortizationSchedule: currentAmortizationSchedule
    };

    const result = window.authManager.saveLoan(loanToSave);
    
    if (result.success) {
      showMessage(result.message, 'success');
      closeSaveModal();
    } else {
      showMessage(result.message, 'error');
    }
  }

  function exportData() {
    if (!currentAmortizationSchedule || !currentLoanData) {
      showMessage('Aucune donnée à exporter', 'error');
      return;
    }

    const csvContent = LoanCalculator.exportToCSV(
      currentAmortizationSchedule,
      currentLoanData,
      currentLoanData.currency
    );

    const filename = `amortissement_${new Date().toISOString().split('T')[0]}.csv`;
    LoanCalculator.downloadCSV(csvContent, filename);
    
    showMessage('Données exportées avec succès', 'success');
  }

  function printTable() {
    const printWindow = window.open('', '_blank');
    const tableHTML = document.getElementById('amortization-table').outerHTML;
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Tableau d'amortissement</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f5f5f5; font-weight: bold; }
          tr:nth-child(even) { background-color: #f9f9f9; }
          h1 { color: #333; }
          .summary { margin-bottom: 20px; }
          .summary p { margin: 5px 0; }
        </style>
      </head>
      <body>
        <h1>Tableau d'amortissement</h1>
        <div class="summary">
          <p><strong>Montant du prêt:</strong> ${LoanCalculator.formatCurrency(currentLoanData.principal, currentLoanData.currency)}</p>
          <p><strong>Taux d'intérêt:</strong> ${currentLoanData.annualRate}%</p>
          <p><strong>Durée:</strong> ${currentLoanData.durationMonths} mois</p>
          <p><strong>Mensualité:</strong> ${LoanCalculator.formatCurrency(currentLoanData.monthlyPayment, currentLoanData.currency)}</p>
          <p><strong>Date d'impression:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
        ${tableHTML}
      </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
  }

  function showMessage(message, type = 'info') {
    // Créer ou réutiliser l'élément de message
    let messageEl = document.querySelector('.message');
    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.className = 'message';
      document.querySelector('.container').insertBefore(messageEl, document.querySelector('.calculator-header'));
    }

    messageEl.textContent = message;
    messageEl.className = `message ${type}`;
    messageEl.style.display = 'block';

    // Masquer automatiquement après 5 secondes
    setTimeout(() => {
      messageEl.style.display = 'none';
    }, 5000);
  }

  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Mise à jour de l'UI au chargement
  window.addEventListener('load', updateAuthUI);
});