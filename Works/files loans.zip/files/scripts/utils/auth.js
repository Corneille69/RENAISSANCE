// Utilitaires d'authentification
class AuthManager {
  constructor() {
    this.currentUser = null;
    this.init();
  }

  init() {
    // Charger l'utilisateur depuis sessionStorage
    const savedUser = sessionStorage.getItem('zenloan_current_user');
    if (savedUser) {
      try {
        this.currentUser = JSON.parse(savedUser);
      } catch (e) {
        console.error('Erreur lors du chargement de l\'utilisateur:', e);
        sessionStorage.removeItem('zenloan_current_user');
      }
    }
    
    this.updateUI();
  }

  // Inscription d'un nouvel utilisateur
  register(name, email, password) {
    try {
      // Vérifier si l'email existe déjà
      const users = this.getUsers();
      if (users.find(user => user.email === email)) {
        throw new Error('Un compte avec cette adresse e-mail existe déjà');
      }

      // Créer le nouvel utilisateur
      const newUser = {
        id: this.generateId(),
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password: this.hashPassword(password),
        createdAt: new Date().toISOString(),
        loans: []
      };

      // Sauvegarder dans localStorage
      users.push(newUser);
      localStorage.setItem('zenloan_users', JSON.stringify(users));

      // Connecter automatiquement l'utilisateur
      this.login(email, password);
      
      return { success: true, message: 'Compte créé avec succès !' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // Connexion d'un utilisateur
  login(email, password) {
    try {
      const users = this.getUsers();
      const user = users.find(user => 
        user.email === email.trim().toLowerCase() && 
        user.password === this.hashPassword(password)
      );

      if (!user) {
        throw new Error('Adresse e-mail ou mot de passe incorrect');
      }

      // Sauvegarder la session
      this.currentUser = { ...user };
      delete this.currentUser.password; // Ne pas stocker le mot de passe en session
      sessionStorage.setItem('zenloan_current_user', JSON.stringify(this.currentUser));
      
      this.updateUI();
      
      return { success: true, message: 'Connexion réussie !' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // Déconnexion
  logout() {
    this.currentUser = null;
    sessionStorage.removeItem('zenloan_current_user');
    this.updateUI();
    
    // Rediriger vers la page d'accueil
    if (window.location.pathname !== '/index.html' && window.location.pathname !== '/') {
      window.location.href = 'index.html';
    }
  }

  // Vérifier si l'utilisateur est connecté
  isAuthenticated() {
    return this.currentUser !== null;
  }

  // Obtenir l'utilisateur actuel
  getCurrentUser() {
    return this.currentUser;
  }

  // Obtenir tous les utilisateurs
  getUsers() {
    try {
      const users = localStorage.getItem('zenloan_users');
      return users ? JSON.parse(users) : [];
    } catch (e) {
      console.error('Erreur lors du chargement des utilisateurs:', e);
      return [];
    }
  }

  // Sauvegarder un prêt pour l'utilisateur actuel
  saveLoan(loanData) {
    if (!this.isAuthenticated()) {
      throw new Error('Vous devez être connecté pour sauvegarder un prêt');
    }

    try {
      const users = this.getUsers();
      const userIndex = users.findIndex(user => user.id === this.currentUser.id);
      
      if (userIndex === -1) {
        throw new Error('Utilisateur non trouvé');
      }

      // Ajouter le prêt à l'utilisateur
      const loan = {
        id: this.generateId(),
        ...loanData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (!users[userIndex].loans) {
        users[userIndex].loans = [];
      }
      
      users[userIndex].loans.push(loan);
      
      // Mettre à jour dans localStorage
      localStorage.setItem('zenloan_users', JSON.stringify(users));
      
      // Mettre à jour l'utilisateur actuel
      this.currentUser.loans = users[userIndex].loans;
      sessionStorage.setItem('zenloan_current_user', JSON.stringify(this.currentUser));
      
      return { success: true, message: 'Prêt sauvegardé avec succès !', loan };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // Supprimer un prêt
  deleteLoan(loanId) {
    if (!this.isAuthenticated()) {
      throw new Error('Vous devez être connecté pour supprimer un prêt');
    }

    try {
      const users = this.getUsers();
      const userIndex = users.findIndex(user => user.id === this.currentUser.id);
      
      if (userIndex === -1) {
        throw new Error('Utilisateur non trouvé');
      }

      // Supprimer le prêt
      users[userIndex].loans = users[userIndex].loans.filter(loan => loan.id !== loanId);
      
      // Mettre à jour dans localStorage
      localStorage.setItem('zenloan_users', JSON.stringify(users));
      
      // Mettre à jour l'utilisateur actuel
      this.currentUser.loans = users[userIndex].loans;
      sessionStorage.setItem('zenloan_current_user', JSON.stringify(this.currentUser));
      
      return { success: true, message: 'Prêt supprimé avec succès !' };
    } catch (error) {
      return { success: false, message: error.message };
    }
  }

  // Mettre à jour l'interface utilisateur
  updateUI() {
    const authLinks = document.querySelectorAll('#auth-link');
    authLinks.forEach(link => {
      if (this.isAuthenticated()) {
        link.textContent = this.currentUser.name;
        link.href = 'auth.html';
      } else {
        link.textContent = 'Connexion';
        link.href = 'auth.html';
      }
    });
  }

  // Utilitaires privées
  generateId() {
    return 'id_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  }

  hashPassword(password) {
    // Simple hash pour le stockage local (ne pas utiliser en production)
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return hash.toString();
  }

  // Valider l'email
  validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Valider le mot de passe
  validatePassword(password) {
    return password && password.length >= 6;
  }
}

// Instance globale
window.authManager = new AuthManager();