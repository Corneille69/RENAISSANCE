// Utilitaires de calcul pour les prêts
class LoanCalculator {
  static calculateMonthlyPayment(principal, annualRate, durationMonths) {
    if (annualRate === 0) {
      return principal / durationMonths;
    }
    
    const monthlyRate = annualRate / 100 / 12;
    const payment = principal * (monthlyRate * Math.pow(1 + monthlyRate, durationMonths)) / 
                   (Math.pow(1 + monthlyRate, durationMonths) - 1);
    
    return payment;
  }

  static calculateLoanDetails(amount, rate, duration, durationType = 'years') {
    const principal = parseFloat(amount);
    const annualRate = parseFloat(rate);
    const durationMonths = durationType === 'years' ? duration * 12 : duration;
    
    const monthlyPayment = this.calculateMonthlyPayment(principal, annualRate, durationMonths);
    const totalCost = monthlyPayment * durationMonths;
    const totalInterest = totalCost - principal;
    
    return {
      principal,
      annualRate,
      durationMonths,
      monthlyPayment,
      totalCost,
      totalInterest
    };
  }

  static generateAmortizationSchedule(principal, annualRate, durationMonths) {
    const schedule = [];
    let remainingBalance = principal;
    const monthlyRate = annualRate / 100 / 12;
    const monthlyPayment = this.calculateMonthlyPayment(principal, annualRate, durationMonths);
    
    for (let month = 1; month <= durationMonths; month++) {
      const interestPayment = remainingBalance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      remainingBalance = Math.max(0, remainingBalance - principalPayment);
      
      schedule.push({
        month,
        payment: monthlyPayment,
        principal: principalPayment,
        interest: interestPayment,
        balance: remainingBalance
      });
    }
    
    return schedule;
  }

  static formatCurrency(amount, currency = 'XOF') {
    const formatter = new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
    
    return formatter.format(amount);
  }

  static getCurrencySymbol(currency) {
    const symbols = {
      'EUR': '€',
      'USD': '$',
      'XOF': 'FCFA',
      'GBP': '£',
      'CHF': 'CHF'
    };
    
    return symbols[currency] || currency;
  }

  static exportToCSV(schedule, loanDetails, currency) {
    const headers = ['Mois', 'Mensualité', 'Capital', 'Intérêts', 'Solde restant'];
    const rows = schedule.map(item => [
      item.month,
      this.formatNumber(item.payment),
      this.formatNumber(item.principal),
      this.formatNumber(item.interest),
      this.formatNumber(item.balance)
    ]);
    
    const csvContent = [
      `Tableau d'amortissement - ${new Date().toLocaleDateString()}`,
      `Montant: ${this.formatCurrency(loanDetails.principal, currency)}`,
      `Taux: ${loanDetails.annualRate}%`,
      `Durée: ${loanDetails.durationMonths} mois`,
      '',
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');
    
    return csvContent;
  }

  static formatNumber(number) {
    return new Intl.NumberFormat('fr-FR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(number);
  }

  static downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
}

window.LoanCalculator = LoanCalculator;