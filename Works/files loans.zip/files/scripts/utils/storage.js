// Utilitaires de stockage local
class StorageManager {
  constructor() {
    this.prefix = 'zenloan_';
  }

  // Sauvegarder des données
  save(key, data) {
    try {
      const serializedData = JSON.stringify(data);
      localStorage.setItem(this.prefix + key, serializedData);
      return true;
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      return false;
    }
  }

  // Charger des données
  load(key) {
    try {
      const data = localStorage.getItem(this.prefix + key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
      return null;
    }
  }

  // Supprimer des données
  remove(key) {
    try {
      localStorage.removeItem(this.prefix + key);
      return true;
    } catch (error) {
      console.error('Erreur lors de la suppression:', error);
      return false;
    }
  }

  // Vérifier si une clé existe
  exists(key) {
    return localStorage.getItem(this.prefix + key) !== null;
  }

  // Obtenir toutes les clés avec le préfixe
  getAllKeys() {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(this.prefix)) {
        keys.push(key.substring(this.prefix.length));
      }
    }
    return keys;
  }

  // Nettoyer toutes les données de l'application
  clear() {
    const keys = this.getAllKeys();
    keys.forEach(key => this.remove(key));
  }

  // Obtenir la taille utilisée en Ko
  getStorageSize() {
    let totalSize = 0;
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key) && key.startsWith(this.prefix)) {
        totalSize += localStorage[key].length;
      }
    }
    return Math.round(totalSize / 1024 * 100) / 100; // En Ko
  }

  // Vérifier la capacité disponible
  checkCapacity() {
    try {
      const testKey = this.prefix + 'test';
      const testData = new Array(1024).join('a'); // 1Ko de test
      localStorage.setItem(testKey, testData);
      localStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  }

  // Sauvegarder l'historique des calculs
  saveCalculationHistory(calculation) {
    const history = this.load('calculation_history') || [];
    const newCalculation = {
      ...calculation,
      id: 'calc_' + Date.now(),
      timestamp: new Date().toISOString()
    };
    
    history.unshift(newCalculation);
    
    // Limiter à 50 calculs
    if (history.length > 50) {
      history.splice(50);
    }
    
    return this.save('calculation_history', history);
  }

  // Obtenir l'historique des calculs
  getCalculationHistory() {
    return this.load('calculation_history') || [];
  }

  // Sauvegarder les préférences utilisateur
  saveUserPreferences(preferences) {
    return this.save('user_preferences', preferences);
  }

  // Charger les préférences utilisateur
  getUserPreferences() {
    const defaultPreferences = {
      currency: 'XOF',
      durationType: 'years',
      chartType: 'line',
      theme: 'light'
    };
    
    const saved = this.load('user_preferences');
    return saved ? { ...defaultPreferences, ...saved } : defaultPreferences;
  }

  // Exporter toutes les données utilisateur
  exportAllData() {
    const data = {};
    const keys = this.getAllKeys();
    
    keys.forEach(key => {
      data[key] = this.load(key);
    });
    
    return {
      exportDate: new Date().toISOString(),
      version: '1.0',
      data: data
    };
  }

  // Importer des données
  importData(exportedData) {
    try {
      if (!exportedData.data) {
        throw new Error('Format de données invalide');
      }
      
      // Sauvegarde des données actuelles
      const backup = this.exportAllData();
      
      try {
        // Import des nouvelles données
        Object.keys(exportedData.data).forEach(key => {
          this.save(key, exportedData.data[key]);
        });
        
        return { success: true, message: 'Données importées avec succès' };
      } catch (error) {
        // Restauration en cas d'erreur
        Object.keys(backup.data).forEach(key => {
          this.save(key, backup.data[key]);
        });
        throw error;
      }
    } catch (error) {
      return { success: false, message: 'Erreur lors de l\'import: ' + error.message };
    }
  }
}

// Instance globale
window.storageManager = new StorageManager();