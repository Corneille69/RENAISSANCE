import tkinter as tk
from tkinter import messagebox
import sqlite3
from datetime import datetime

# Connexion à la base SQLite
conn = sqlite3.connect('absences.db')
cursor = conn.cursor()

# Création de la table si non existante
cursor.execute('''
CREATE TABLE IF NOT EXISTS absences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    heure TEXT,
    filiere TEXT,
    cours TEXT,
    etudiant TEXT,
    statut TEXT,
    duree TEXT,
    justification TEXT
)
''')
conn.commit()

HEURE_COURS = datetime.strptime("08:00", "%H:%M")

# Étudiants par filière
etudiants_par_filiere = {
    "CS27": [
        "BADO Yannick", "BADOLO Patricia", "BALIMA Hectore", "BAMOUNI Grace", "BASSINGA Jessica",
        "BATIONO Betranel", "BIRBA Wendabo Casimir", "BONKOUNGOU Jerome", "BOUNKOUGOU Wendyam Vanessa",
        "BOUDA Mouniratou", "BOUGMA Sadiata", "COMPAORE Adim Fahim Saidou", "COMPAORE Kisito",
        "COMPAORE Salimata", "CONGO Anifatou", "COULIBALY Faez", "DAH Cheoutierou", "DAKUYO Prisca",
        "DAYAMBA Abigael", "DEHOUMOU Christelle", "DEMBELE Gaethan Khaleb", "DIALLO Maimata",
        "DORI Marie Madeleine", "DOUAMBASidonie", "DRABO Farel", "GADIERE Farida",
        "GARANE Farida Kevine", "ILBOUDO Balkissa", "ILBOUDO John Michee", "KABORE Albertine",
        "KABORE Karelle 2e jumelle", "KABORE Odiane Elia", "KABORE Grace Oceanne", "KABORE Awa",
        "KABORE Bienvenu", "KAFANDO Dan", "KAGAMBEGA Saturne", "KAGAMBEGA Claudine", "KAMBOU Yeri Hermine",
        "KANTAGBA Efraim", "KANTIONO Diane", "KERE Noeldinolippeu", "KIEMTORE Simplice",
        "KIENDREBEOGO Carine", "KIENDREBEOGO Sephora", "KIENDREBEOGO Moussa", "KIENDREBEOGO Arnaud",
        "KINI Jacob", "KOALGA Heliane", "KOANDA Checkib", "KOLOGO Robert", "KONDOMBO Josue",
        "KONOMBO Madeleine", "KOUTIEBOU Ornella", "KYEMTORE Gloria", "MANDI Melki", "MEDA Franck",
        "NACOULMA Betsaleel", "NANA Prisca", "NANA Marc", "NASSA Didier", "NIKIEMA Flora Marie Ines",
        "NIKIEMA Marieta", "NITIEMA Eddy Martial", "NKUNA Israel", "NOMBRE Ange", "N'ZOMBIE Rodrigue",
        "OUATTARA Fawzia", "OUEDRAOGO Corneille", "OUEDRAOGO Landry", "OUEDRAOGO Akram",
        "OUEDRAOGO Alimata", "OUEDRAOGO Adele", "OUEDRAOGO Jonathan", "OUEDRAOGO Esther",
        "OUEDRAOGO Abdoulaye", "OUILY Nasser", "PARE Joseph", "PARE Boris Marcel", "PARE Assetou",
        "ROUAMBA Mounira", "ROUAMBA Sarifatou", "SANFO Madi", "SANON Abdoul Ben Fatao",
        "SAWADOGO Grace", "SAWADOGO Elisabeth", "SAWADOGO Azael", "SAWADOGO Asseta", "SAWADOGO Risnata",
        "SEMDE Aicha", "SIMPORE Alima", "SIMPORE Sidiki", "SOULAMA Ulrich", "TANKOANO Michel",
        "TAO Fazollah", "TOE Kevin", "TOUBRIWOUMYIAN Yan Ulrich", "TOUGOUMA Trevis", "TRAORE Ramatou",
        "TRAORE Mathias", "TRAORE ESmelle", "WANGRE Esther", "ZABRE Elvine", "YABRE Amma",
        "YAMEOGO Aymar", "YAMEOGO Cedric", "YAMEOGO Athanasse", "YAMEOGO Angeline", "YAMEOGO Firmin",
        "YAMEOGO Marie Joseph", "YAMEOGO Claudine", "YANOGO Stephanie", "YELEMOU Martial",
        "YOUGBARE Eunice", "ZABRE Tania", "ZAMANE Elodie", "ZARANI Abdoul Kader", "ZINGUE Cynthia",
        "ZOMA Amelie", "ZONGO P.Juste", "ZONGO Pascal", "ZONGO Ange Anselme", "ZONGO Alida Isidore",
        "ZONGO Malkiram", "ZONGO Safiatou", "ZONGO Abdel Sadek", "ZOUGOURI Aurel Clauvis",
        "ZOUNGRANA Brenger", "ZOUNGRANA Zalissa", "ZOUNGRANA Eulalie", "ZOUNGRANA Sébastien"
    ],
}

statut_vars = {}
minuteurs_retard = {}
minuteurs_absent = {}

def afficher_etudiants():
    for widget in frame_etudiants.winfo_children():
        widget.destroy()

    filiere = var_filiere.get()
    if filiere not in etudiants_par_filiere:
        return

    etudiants = etudiants_par_filiere[filiere]
    statut_vars.clear()

    for nom in etudiants:
        frame = tk.Frame(frame_etudiants, bg="#f0f8ff")
        frame.pack(fill="x", pady=2)

        label = tk.Label(frame, text=nom, width=30, anchor="w", bg="#f0f8ff")
        label.pack(side="left")

        var_abs = tk.IntVar()
        var_retard = tk.IntVar()
        statut_vars[nom] = (var_abs, var_retard)

        cb_abs = tk.Checkbutton(frame, text="Absent", variable=var_abs, bg="#f0f8ff",
                                command=lambda n=nom: toggle_minuteur_absent(n))
        cb_abs.pack(side="left")

        cb_retard = tk.Checkbutton(frame, text="Retard", variable=var_retard, bg="#f0f8ff",
                                   command=lambda n=nom: toggle_minuteur_retard(n))
        cb_retard.pack(side="left")

def toggle_minuteur_absent(nom):
    if statut_vars[nom][0].get() == 1:
        # Démarrer minuteur absence
        minuteurs_absent[nom] = datetime.now()
        ouvrir_minuteur_absent(nom)
    else:
        # Si décoché, on peut arrêter manuellement via la fenêtre minuteries (ou ici on ignore)
        if nom in minuteurs_absent:
            del minuteurs_absent[nom]

def toggle_minuteur_retard(nom):
    if statut_vars[nom][1].get() == 1:
        # Démarrer minuteur retard (calcul par rapport à 08:00)
        minuteurs_retard[nom] = datetime.now()
        ouvrir_minuteur_retard(nom)
    else:
        if nom in minuteurs_retard:
            del minuteurs_retard[nom]

# Fenêtre pour minuterie des absents
def ouvrir_minuteur_absent(nom):
    fen = tk.Toplevel(fenetre)
    fen.title(f"Minuteur Absence - {nom}")
    fen.geometry("300x100")

    label = tk.Label(fen, text=f"{nom} : absence en cours...", font=("Arial", 12))
    label.pack(pady=10)

    def arreter():
        if nom in minuteurs_absent:
            debut = minuteurs_absent[nom]
            duree = datetime.now() - debut
            minutes = duree.seconds // 60
            secondes = duree.seconds % 60
            duree_str = f"{minutes} min {secondes} s"
            label.config(text=f"Durée absence : {duree_str}")
            bouton_arret.config(state="disabled")
            minuteurs_absent[nom] = duree_str  # Remplacer datetime par durée calculée

    bouton_arret = tk.Button(fen, text="Arrêter", command=arreter, bg="red", fg="white")
    bouton_arret.pack()

# Fenêtre pour minuterie des retardataires (calcul depuis 08:00)
def ouvrir_minuteur_retard(nom):

    fen = tk.Toplevel(fenetre)
    fen.title(f"Minuteur Retard - {nom}")
    fen.geometry("300x100")

    label = tk.Label(fen, text=f"{nom} : retard en cours...", font=("Arial", 12))
    label.pack(pady=10)

    def arreter():
        maintenant = datetime.now()
        retard = maintenant - HEURE_COURS
        minutes = retard.seconds // 60
        secondes = retard.seconds % 60
        duree_str = f"{minutes} min {secondes} s"
        label.config(text=f"Durée retard : {duree_str}")
        bouton_arret.config(state="disabled")
        minuteurs_retard[nom] = duree_str

    bouton_arret = tk.Button(fen, text="Arrêter", command=arreter, bg="red", fg="white")
    bouton_arret.pack()

def enregistrer():
    cours = entree_cours.get().strip()
    filiere = var_filiere.get().strip()
    if filiere == "" or cours == "":
        messagebox.showwarning("Champs manquants", "Veuillez remplir tous les champs.")
        return

    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    heure_str = now.strftime("%H:%M")

    lignes_enregistrees = []

    for nom, (var_abs, var_retard) in statut_vars.items():
        if var_abs.get() == 0 and var_retard.get() == 0:
            continue

        statut = "Absent" if var_abs.get() == 1 else "Retard"

        # Récupérer durée depuis minuteur si existant
        if statut == "Absent":
            duree = minuteurs_absent.get(nom, "")
            if isinstance(duree, datetime):
                # si encore datetime, calculer durée jusqu'à maintenant
                duree = str(datetime.now() - duree)
        else:
            duree = minuteurs_retard.get(nom, "")
            if isinstance(duree, datetime):
                duree = str(datetime.now() - duree)

        cursor.execute('''
            INSERT INTO absences(date, heure, filiere, cours, etudiant, statut, duree, justification)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (date_str, heure_str, filiere, cours, nom, statut, duree, ""))
        lignes_enregistrees.append((date_str, heure_str, filiere, cours, nom, statut, duree, ""))

    conn.commit()
    afficher_recapitulatif(lignes_enregistrees)
    # Nettoyer minuteurs
    minuteurs_absent.clear()
    minuteurs_retard.clear()
    # Reset checkboxes
    for var_abs, var_retard in statut_vars.values():
        var_abs.set(0)
        var_retard.set(0)

def afficher_recapitulatif(lignes):
    recap = tk.Toplevel(fenetre)
    recap.title("Récapitulatif des absences et retards")
    text = tk.Text(recap, width=100, height=25)
    text.pack(padx=10, pady=10)
    text.insert(tk.END, "Date | Heure | Filière | Cours | Étudiant | Statut | Durée | Justification\n")
    text.insert(tk.END, "-"*120 + "\n")
    for ligne in lignes:
        text.insert(tk.END, " | ".join(str(item) for item in ligne) + "\n")
    text.config(state=tk.DISABLED)

def verifier_acces_justification():
    def verifier():
        utilisateur = champ_user.get()
        mot_de_passe = champ_mdp.get()
        if utilisateur == "M.SAMA" and mot_de_passe == "251":
            fen_mdp.destroy()
            ouvrir_interface_justification()
        else:
            messagebox.showerror("Erreur", "Nom d'utilisateur ou mot de passe incorrect.")

    fen_mdp = tk.Toplevel(fenetre)
    fen_mdp.title("Connexion sécurisée")
    fen_mdp.geometry("300x150")

    tk.Label(fen_mdp, text="Nom d'utilisateur :").pack(pady=(10, 2))
    champ_user = tk.Entry(fen_mdp)
    champ_user.pack()

    tk.Label(fen_mdp, text="Mot de passe :").pack(pady=(10, 2))
    champ_mdp = tk.Entry(fen_mdp, show="*")
    champ_mdp.pack()

    tk.Button(fen_mdp, text="Valider", command=verifier, bg="blue", fg="white").pack(pady=10)

def ouvrir_interface_justification():
    fen_justif = tk.Toplevel(fenetre)
    fen_justif.title("Justification des absences et retards")
    fen_justif.geometry("900x600")

    tk.Label(fen_justif, text="Ajouter une justification :", font=("Arial", 14, "bold")).pack(pady=10)

    filtre_var = tk.StringVar(value="Tous")
    frame_filtre = tk.Frame(fen_justif)
    frame_filtre.pack()

    for option in ["Tous", "Absent", "Retard"]:
        rb = tk.Radiobutton(frame_filtre, text=option, variable=filtre_var, value=option, command=lambda: afficher_liste_justif())
        rb.pack(side="left", padx=10)

    canvas = tk.Canvas(fen_justif)
    frame_liste = tk.Frame(canvas)
    scrollbar_vert = tk.Scrollbar(fen_justif, orient="vertical", command=canvas.yview)
    scrollbar_horz = tk.Scrollbar(fen_justif, orient="horizontal", command=canvas.xview)
    canvas.configure(yscrollcommand=scrollbar_vert.set, xscrollcommand=scrollbar_horz.set)

    scrollbar_vert.pack(side="right", fill="y")
    scrollbar_horz.pack(side="bottom", fill="x")
    canvas.pack(side="left", fill="both", expand=True)
    canvas.create_window((0,0), window=frame_liste, anchor="nw")

    frame_liste.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    entries_justif = {}

    def afficher_liste_justif():
        for widget in frame_liste.winfo_children():
            widget.destroy()
        entries_justif.clear()

        filtre = filtre_var.get()
        query = "SELECT id, etudiant, statut, justification FROM absences"
        params = ()
        if filtre != "Tous":
            query += " WHERE statut = ?"
            params = (filtre,)

        cursor.execute(query, params)
        lignes = cursor.fetchall()

        tk.Label(frame_liste, text="Étudiant", width=30, borderwidth=1, relief="solid").grid(row=0, column=0)
        tk.Label(frame_liste, text="Statut", width=10, borderwidth=1, relief="solid").grid(row=0, column=1)
        tk.Label(frame_liste, text="Justification", width=60, borderwidth=1, relief="solid").grid(row=0, column=2)

        for i, (id_, etudiant, statut, justification) in enumerate(lignes, start=1):
            tk.Label(frame_liste, text=etudiant, width=30, anchor="w", borderwidth=1, relief="solid").grid(row=i, column=0)
            tk.Label(frame_liste, text=statut, width=10, borderwidth=1, relief="solid").grid(row=i, column=1)

            entry = tk.Entry(frame_liste, width=60)
            entry.grid(row=i, column=2)
            if justification:
                entry.insert(0, justification)
            entries_justif[id_] = entry

    def sauvegarder_justifications():
        for id_, entry in entries_justif.items():
            justif = entry.get().strip()
            cursor.execute("UPDATE absences SET justification = ? WHERE id = ?", (justif, id_))
        conn.commit()
        messagebox.showinfo("Sauvegardé", "Justifications enregistrées avec succès.")

    btn_sauvegarder = tk.Button(fen_justif, text="Sauvegarder les justifications", command=sauvegarder_justifications, bg="green", fg="white")
    btn_sauvegarder.pack(pady=10)

    afficher_liste_justif()

# --- Fenêtre principale ---

fenetre = tk.Tk()
fenetre.title("Gestion Absences et Retards - CS27")
fenetre.geometry("850x600")

frame_haut = tk.Frame(fenetre)
frame_haut.pack(pady=10)

tk.Label(frame_haut, text="Filière :").pack(side="left", padx=5)
var_filiere = tk.StringVar(value="CS27")
option_filiere = tk.OptionMenu(frame_haut, var_filiere, *etudiants_par_filiere.keys(), command=lambda _: afficher_etudiants())
option_filiere.pack(side="left")

tk.Label(frame_haut, text="Cours :").pack(side="left", padx=5)
entree_cours = tk.Entry(frame_haut)
entree_cours.pack(side="left")

btn_enregistrer = tk.Button(frame_haut, text="Enregistrer", command=enregistrer, bg="blue", fg="white")
btn_enregistrer.pack(side="left", padx=10)

btn_justif = tk.Button(frame_haut, text="Justifications", command=verifier_acces_justification, bg="orange")
btn_justif.pack(side="left", padx=10)

# Cadre avec scrollbar horizontal et vertical
frame_principal = tk.Frame(fenetre)
frame_principal.pack(fill="both", expand=True)

canvas = tk.Canvas(frame_principal)
frame_etudiants = tk.Frame(canvas)
scrollbar_vert = tk.Scrollbar(frame_principal, orient="vertical", command=canvas.yview)
scrollbar_horz = tk.Scrollbar(frame_principal, orient="horizontal", command=canvas.xview)

canvas.configure(yscrollcommand=scrollbar_vert.set, xscrollcommand=scrollbar_horz.set)

scrollbar_vert.pack(side="right", fill="y")
scrollbar_horz.pack(side="bottom", fill="x")
canvas.pack(side="left", fill="both", expand=True)

canvas.create_window((0, 0), window=frame_etudiants, anchor="nw")

def on_frame_configure(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

frame_etudiants.bind("<Configure>", on_frame_configure)

afficher_etudiants()

fenetre.mainloop()