from flask import Flask, render_template, request, redirect, flash, url_for
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from flask import session  
from datetime import datetime
from functools import wraps
from flask import make_response
from weasyprint import HTML
import tempfile
from flask import send_file

import os
import sys



app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Necessary for flash messages 



def role_required(allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'username' not in session or 'spot' not in session:
                flash('Please log in first.', 'error')
                return redirect(url_for('login'))
            if session['spot'].lower() not in allowed_roles:
                flash('Access denied: insufficient permissions.', 'error')
                return redirect(url_for('login', next=request.path))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def init_db():
    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS students (
            ID TEXT PRIMARY KEY,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            field TEXT NOT NULL,
            promotion INTEGER NOT NULL,
            gender TEXT NOT NULL
        )

    ''')

    c.execute('''
    CREATE TABLE IF NOT EXISTS weekly_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        week_number TEXT,
        student_id TEXT,
        presents INTEGER,
        absents INTEGER,
        total INTEGER,
        FOREIGN KEY(student_id) REFERENCES students(ID)
     )
 ''')

    
    c.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            status TEXT NOT NULL,
            date TEXT NOT NULL,
            FOREIGN KEY(student_id) REFERENCES students(ID)
        )
    ''')

    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            spot TEXT NOT NULL
        )
    ''')

    conn.commit()
    conn.close()




@app.route('/')
def index():
    return render_template('Acceuil.html')

@app.route('/submit', methods=['POST','GET'])
def submit():
    student_id = request.form['ID']
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    field = request.form['field']
    promotion = request.form['promotion']
    gender = request.form['gender']

    conn = sqlite3.connect('students.db')
    c = conn.cursor()
    try:
        c.execute('''
            INSERT INTO students (ID, first_name, last_name, field, promotion, gender)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (student_id, first_name, last_name, field, promotion, gender))
        conn.commit()
        flash(" Student registered successfully!", "success")
    except sqlite3.IntegrityError:
        flash(" Error: ID already exists.", "error")
    finally:
        conn.close()

    return redirect(url_for('form'))


@app.route('/submit_attendance', methods=['POST'])
@role_required(['administration', 'class leader', 'vice class leader'])
def submit_attendance():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    today = datetime.now().strftime("%Y-%m-%d")

    for key, value in request.form.items():
        if key.startswith('presence_'):
            ID = key.replace('presence_', '')
            status = value  # "Present" or "Absent"

            # Check if already note today
            cursor.execute('SELECT * FROM attendance WHERE student_id = ? AND date = ?', (ID, today))
            if cursor.fetchone() is None:
                cursor.execute('''
                    INSERT INTO attendance (student_id, status, date)
                    VALUES (?, ?, ?)
                ''', (ID, status, today))

    conn.commit()
    conn.close()
    return redirect(url_for('home'))


        
@app.route('/attendance')
@role_required(['administration', 'class leader', 'vice class leader'])
def attendance():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    today = datetime.now().strftime("%Y-%m-%d")

    # Only display the students that not marqued their attendance today 
    students = cursor.execute('''
        SELECT * FROM students
        WHERE ID NOT IN (
            SELECT ID FROM attendance WHERE date = ?
        )
    ''', (today,)).fetchall()

    conn.close()
    return render_template('attendance.html', students=students)

    
@app.route('/weekly_report')
@role_required(['administration', 'class leader', 'vice class leader'])
def weekly_report():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    # Compute attendance of the current week
    cursor.execute('''
        SELECT s.ID, s.first_name, s.last_name, s.promotion,
                SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) as presents,
                SUM(CASE WHEN a.status = "Absent" THEN 1 ELSE 0 END) as absents,
                COUNT(a.status) as total
        FROM students s
        LEFT JOIN attendance a 
            ON s.ID = a.student_id
            AND strftime('%W', a.date) = strftime('%W', 'now')
        GROUP BY s.ID
    ''')

    report = cursor.fetchall()
    conn.close()
    return render_template('weekly_report.html', report=report)


@app.route('/all_weekly_reports')
def all_weekly_reports():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM weekly_reports
        ORDER BY week_number DESC, student_id ASC
    ''')
    data = cursor.fetchall()
    conn.close()
    return render_template('all_weekly_reports.html', data=data)


@app.route('/download_report/<filename>')
def download_report(filename):
    return send_from_directory('static/reports', filename, as_attachment=True)



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        spot= request.form['spot']

        # Hashe the password
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')


        conn = sqlite3.connect('students.db')
        c = conn.cursor()

        try:
            c.execute('INSERT INTO users (username, password,spot) VALUES (?, ?,?)', (username, hashed_password,spot))
            conn.commit()
            flash('Account created successfully! You can now log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists. Please choose another.', 'error')
        finally:
            conn.close()

    return render_template('signup.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        spot = request.form['spot'].strip().lower()  # CLeanning and putting in small caractere 

        conn = sqlite3.connect('students.db')
        c = conn.cursor()
        c.execute('SELECT password, spot FROM users WHERE username = ?', (username,))
        user = c.fetchone()
        conn.close()

        if user:
            stored_password, stored_spot = user
            if check_password_hash(stored_password, password):
                allowed_spots = ['administration', 'class leader', 'vice class leader']
                if stored_spot.strip().lower() in allowed_spots:
                    session['username'] = username
                    session['spot'] = stored_spot.strip().lower()
                    flash('✅ Logged in successfully!', 'success')
                    next_page = request.args.get('next')  # Where to come back!
                    return redirect(next_page or url_for('home'))  #  redirect to the right page
                else:
                    flash('⛔ Access denied: only administration, class leader, or vice class leader  can log in.', 'error')
            else:
                flash('❌ Invalid password.', 'error')
        else:
            flash('❌ Username not found.', 'error')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()  # Remove all informations about the session (like 'username' and 'spot')
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))


# Rediriger les warnings GTK vers nul
sys.stderr = open(os.devnull, 'w')


def obtenir_donnees_depuis_db():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT s.ID, s.first_name, s.last_name, s.promotion,
               SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) as presents,
               SUM(CASE WHEN a.status = "Absent" THEN 1 ELSE 0 END) as absents,
               COUNT(a.status) as total
        FROM students s
        LEFT JOIN attendance a 
            ON s.ID = a.student_id
            AND strftime('%W', a.date) = strftime('%W', 'now')
        GROUP BY s.ID
    ''')
    data = cursor.fetchall()
    conn.close()
    return data



@app.route('/export_pdf')
def export_pdf():
    # Prépare les données
    data = obtenir_donnees_depuis_db()  # remplace par ta vraie fonction
    rendered = render_template('pdf_template.html', data=data)

    # Crée un fichier temporaire fermé
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        temp_pdf_path = tmp.name

    # Génére le PDF **après** fermeture du fichier
    HTML(string=rendered).write_pdf(temp_pdf_path)

    # Envoie le fichier à l'utilisateur
    return send_file(temp_pdf_path, as_attachment=True, download_name="report.pdf")

    





@app.route('/save_weekly_report', methods=['POST', 'GET'])
@role_required(['administration', 'class leader', 'vice class leader'])
def save_weekly_report():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    # Calculer le numéro de semaine (ex: année + semaine ISO)
    week_number = datetime.now().strftime("%Y-%W")  # Exemple: '2025-24'

    # Récupérer les données du rapport hebdo (mêmes que dans /weekly_report)
    cursor.execute('''
        SELECT s.ID, 
               SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) as presents,
               SUM(CASE WHEN a.status = "Absent" THEN 1 ELSE 0 END) as absents,
               COUNT(a.status) as total
        FROM students s
        LEFT JOIN attendance a 
            ON s.ID = a.student_id
            AND strftime('%W', a.date) = strftime('%W', 'now')
        GROUP BY s.ID
    ''')

    rows = cursor.fetchall()

    # Pour chaque étudiant, insérer ou mettre à jour dans weekly_reports
    for row in rows:
        student_id = row[0]
        presents = row[1] or 0
        absents = row[2] or 0
        total = row[3] or 0

        # Vérifier si un rapport existe déjà pour cette semaine et cet étudiant
        cursor.execute('''
            SELECT id FROM weekly_reports
            WHERE week_number = ? AND student_id = ?
        ''', (week_number, student_id))
        existing = cursor.fetchone()

        if existing:
            # Mettre à jour
            cursor.execute('''
                UPDATE weekly_reports
                SET presents = ?, absents = ?, total = ?
                WHERE id = ?
            ''', (presents, absents, total, existing[0]))
        else:
            # Insérer nouveau
            cursor.execute('''
                INSERT INTO weekly_reports (week_number, student_id, presents, absents, total)
                VALUES (?, ?, ?, ?, ?)
            ''', (week_number, student_id, presents, absents, total))

    conn.commit()
    conn.close()

    flash("Weekly report saved in success!", "success")
    return redirect(url_for('weekly_report'))




@app.route('/all_weekly_reports_with_download')
@role_required(['administration', 'class leader', 'vice class leader'])
def all_weekly_reports_with_download():
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    # Récupérer toutes les semaines distinctes triées décroissant
    cursor.execute('SELECT DISTINCT week_number FROM weekly_reports ORDER BY week_number DESC')
    weeks = [row[0] for row in cursor.fetchall()]

    # Pour chaque semaine, récupérer les données
    all_reports = {}
    for week in weeks:
        cursor.execute('''
            SELECT s.ID, s.first_name, s.last_name, s.promotion,
                   wr.presents, wr.absents, wr.total
            FROM weekly_reports wr
            JOIN students s ON s.ID = wr.student_id
            WHERE wr.week_number = ?
            ORDER BY s.ID
        ''', (week,))
        all_reports[week] = cursor.fetchall()

    conn.close()

    return render_template('all_weekly_reports_with_download.html', all_reports=all_reports)


@app.route('/download_weekly_report_pdf/<week_number>')
@role_required(['administration', 'class leader', 'vice class leader'])
def download_weekly_report_pdf(week_number):
    conn = sqlite3.connect('students.db')
    cursor = conn.cursor()

    cursor.execute('''
        SELECT s.ID, s.first_name, s.last_name, s.promotion,
               wr.presents, wr.absents, wr.total
        FROM weekly_reports wr
        JOIN students s ON s.ID = wr.student_id
        WHERE wr.week_number = ?
        ORDER BY s.ID
    ''', (week_number,))

    raw_data = cursor.fetchall()
    conn.close()

    # Calcul du taux de présence en pourcentage (arrondi à 2 décimales)
    data_with_percentage = []
    for row in raw_data:
        ID, first_name, last_name, promotion, presents, absents, total = row
        percentage = round((presents / total) * 100, 2) if total > 0 else None
        data_with_percentage.append((ID, first_name, last_name, promotion, presents, absents, total, percentage))

    rendered = render_template('pdf_template.html', data=data_with_percentage, week_number=week_number)

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        temp_pdf_path = tmp.name

    HTML(string=rendered).write_pdf(temp_pdf_path)

    return send_file(temp_pdf_path, as_attachment=True, download_name=f"weekly_report{week_number}.pdf")




@app.route('/home')
def home():
    if 'username' not in session:
        flash("Please log in first.", "error")
        return redirect(url_for('login'))
    return render_template('Acceuil.html')

@app.route('/form')
def form():
    return render_template('form.html')


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
